/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.extratobancario;
import View.Menu;
/**
 *
 * @author Alunos
 */
public class ExtratoBancario {

    public static void main(String[] args) {
        Menu menu_tela = new Menu();
        menu_tela.setVisible(true);
    }
}
